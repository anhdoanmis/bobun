<?php get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

		

		<?php if (have_posts()): while (have_posts()) : the_post(); ?>

			<!-- article -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                
                <?php if(!is_front_page()):?>
                <div class="jumbotron jumbotron-fluid">
              <div class="container">
                <h1 class="h1-title-page"><span><?php the_title(); ?></span></h1>
              </div>
            </div>
            <?php endif;?>	
				<?php the_content(); ?>

				<?php comments_template( '', true ); // Remove if you don't want comments ?>

				<br class="clear">

				<?php edit_post_link(); ?>

			</article>
			<!-- /article -->

		<?php endwhile; ?>

		<?php else: ?>

			<!-- article -->
			<article>

				<h2><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h2>

			</article>
			<!-- /article -->

		<?php endif; ?>

		</section>
		<!-- /section -->
	</main>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>
