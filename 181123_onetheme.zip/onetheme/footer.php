			<!-- footer -->
             <?php 
            $redux_options = get_option('redux_demo');
            /*echo '<pre>';
            print_r($redux_options);
            echo '</pre>';*/
        ?>
			<footer class="footer" role="contentinfo">

				<div class="container">
              <div class="logo-F">
              <?php
              $featured_img_url = $redux_options['logo-footer-media']['url'];
    $alt = get_post_meta( $redux_options['logo-footer-media']['id'], '_wp_attachment_image_alt', true);
                $tit = get_the_title($redux_options['logo-footer-media']['id']);
                $alt = empty($alt)?$tit:$alt;
    $featured_img_url = !empty($featured_img_url)?'<img src="'.$featured_img_url.'"   alt="'.$alt.'" title="'.$tit.'">':'';
              ?>
                <a href="<?php echo home_url();?>"><?php echo $featured_img_url;?></a>
              </div>
              <div class="row">
                <div class="col-lg-6">
                  <div class="footer-box">
                    <?php 
                    $content = $redux_options['col1-editor-tiny'];
                    $content = preg_replace('/(<)([img])(\w+)([^>]*>)/', "", $content);
//$content = apply_filters('the_content', $content);
$content = wpautop($content);
$content = str_replace(']]>', ']]&gt;', $content);
echo $content;
                   ?>                    
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="footer-box">
                    <?php $content = $redux_options['col2-editor-tiny'];
                    $content = preg_replace('/(<)([img])(\w+)([^>]*>)/', "", $content);
//$content = apply_filters('the_content', $content);
$content = wpautop($content);
$content = str_replace(']]>', ']]&gt;', $content);
echo $content;?>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="footer-box">
                    <h2>HỖ TRỢ TRỰC TUYẾN</h2>
                    <div class="lienket">
                      <a href="<?php echo $redux_options['link-fb-text'];?>"><i class="fa fa-facebook-square fa-3x fb"></i></a>
                      <a href="<?php echo $redux_options['link-gg-text'];?>"><i class="fa fa-google-plus-square fa-3x google"></i></a>
                      <a href="<?php echo $redux_options['link-tt-text'];?>"><i class="fa fa-twitter fa-3x tw"></i></a>
                      <a href="<?php echo $redux_options['link-yt-text'];?>"><i class="fa fa-youtube-square fa-3x youtube"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

			</footer>
			<!-- /footer -->

		</div>
		<a href="tel:<?php echo $redux_options['phone-corner-text'];?>">
            <div class="fix_tel">
              <div class="ring-alo-phone ring-alo-green ring-alo-show" id="ring-alo-phoneIcon">
                  <div class="ring-alo-ph-circle"></div>
                  <div class="ring-alo-ph-circle-fill"></div>
                  <div class="ring-alo-ph-img-circle">
                      <img class="lazy" src="<?php echo get_template_directory_uri(); ?>/images/icon/phone-ring.png" alt="">
                  </div>
                </div>
                <div class="tel"></div>
            </div>
          </a>
          <a id="back-to-top" class="transition35 show"><i class="fa fa-angle-up"></i><span>TOP</span></a>

		<?php wp_footer(); ?>

		<!-- analytics -->
		<script>
		(function(f,i,r,e,s,h,l){i['GoogleAnalyticsObject']=s;f[s]=f[s]||function(){
		(f[s].q=f[s].q||[]).push(arguments)},f[s].l=1*new Date();h=i.createElement(r),
		l=i.getElementsByTagName(r)[0];h.async=1;h.src=e;l.parentNode.insertBefore(h,l)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
		ga('send', 'pageview');
		</script>

	</body>
</html>
