
// ===== Scroll to Top ==== 
jQuery(window).scroll(function() {
    if (jQuery(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        jQuery('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        jQuery('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
jQuery('#return-to-top').click(function() {      // When arrow is clicked
    jQuery('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
/////////

// mmenu
jQuery(function($) {
    $('nav#menu-mobi').mmenu({
        extensions  : [ 'theme-dark' ],
        setSelected : true,
        counters    : true,
        searchfield : {
            placeholder     : 'Search menu items'
        },
        iconbar     : {
            add         : true,
            size        : 40,
            top         : [ 
                '<a href="#"><span class="fa fa-home"></span></a>'
            ],
            bottom      : [
                
            ]
        },
       
        navbars     : [
            {
                content     : [ 'searchfield' ]
            }, {
                type        : 'tabs',
                content     : [ 
                    
                ]
            }
        ]
    }, {
        searchfield : {
            clear       : true
        },
        navbars     : {
            breadcrumbs : {
                removeFirst : true
            }
        }
    }); 

    /*$('a[href^="#/"]').click(function() {
        alert( 'Thank you for clicking, but that\'s a demo link' );
        return false;
    });*/
});
/////////////

jQuery(document).ready(function($) {

    /*jQuery('.menu-item').hover(function() {
        $(this).addClass('hover-active');
        $(this).siblings().removeClass('hover-active');
    });
    jQuery('.menu-item').click(function(e) {
        e.preventDefault();
        $(this).addClass('hover-active');
        $(this).siblings().removeClass('hover-active');
    })*/
    $('#back-to-top').click(function(){
    //alert( "Handler for .click() called." );
        $('html, body').animate({ scrollTop: 0 }, 'fast');
    });
});


/////////////
jQuery(function() {
    jQuery('.height').matchHeight();
   
});
//////fix top///////

jQuery(document).ready(function() {
    
  var toggleAffix = function(affixElement, scrollElement, wrapper) {
  
    var height = affixElement.outerHeight(),
        top = wrapper.offset().top;
    
    if (scrollElement.scrollTop() > top){
        wrapper.height(height);
        affixElement.addClass("affix");
    }
    else {
        affixElement.removeClass("affix");
        wrapper.height('auto');
    }
      
  };
  jQuery('[data-toggle="affix"]').each(function() {
    var ele = $(this),
        wrapper = $('<div></div>');
    
    ele.before(wrapper);
    $(window).on('scroll resize', function() {
        toggleAffix(ele, $(this), wrapper);
    });
    
    // init
    toggleAffix(ele, $(window), wrapper);
  });
  
});
jQuery(document).ready(function($) {

        var owl = $("#slider-news-home");

        owl.owlCarousel({
            loop:true,
            dots: false,
            nav:false,
            autoplayHoverPause:false,
            autoplay: true,
            autoHeight:false,
            smartSpeed: 700,
            items: 1,
            onInitialize: function (event) {
                if ($('#slider-news-home .owl-item').length <= 1) {
                   this.settings.loop = false;
                }
            }
            

        });
        $(".next_news-home").click(function(){
            owl.trigger('next.owl.carousel');
            })
            $(".prev_news-home").click(function(){
            owl.trigger('prev.owl.carousel');
        })

    });
///////////////////////////
jQuery(document).ready(function($) {
    var owl2 = $('#slider-doitac');
    owl2.owlCarousel({
        margin: 0,
        nav: false,
        loop: true,
        dots: false,
        autoplay: true,
        animation: "fade",
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        onInitialize: function (event) {
                if ($('#slider-doitac .owl-item').length <= 1) {
                   this.settings.loop = false;
                }
            },
        responsive: {
            0: {
                items: 3
            },
            767: {
                items: 5
            },
            1000: {
                items: 10
            }
        }
    });
})
////////////////////////////////
jQuery(document).ready(function($) {

        var owl = $("#box-slider-news");

        owl.owlCarousel({
            loop:true,
            dots: false,
            nav:false,
            autoplayHoverPause:false,
            autoplay: true,
            autoHeight:false,
            smartSpeed: 700,
            items: 1,
            onInitialize: function (event) {
                if ($('#slider-news-home .owl-item').length <= 1) {
                   this.settings.loop = false;
                }
            }
            

        });
        $(".next_box-slider-news").click(function(){
            owl.trigger('next.owl.carousel');
            })
            $(".prev_box-slider-news").click(function(){
            owl.trigger('prev.owl.carousel');
        })

    });
//////////////////////////
jQuery(document).ready(function() {
    jQuery(window).scroll(function() {
        var scroll = jQuery(window).scrollTop();
        if (scroll >= 140) {
            jQuery('.box-menu-primary').addClass('main-menu-wrap main-menu-scroll');
        } else {
            jQuery('.box-menu-primary').removeClass('main-menu-wrap main-menu-scroll');
        }
    });
    // Back to Top
    if (jQuery('#back-to-top').length) {
        var scrollTrigger = 500, // px
            backToTop = function() {
                var scrollTop = jQuery(window).scrollTop();
                if (scrollTop > scrollTrigger) {
                    jQuery('#back-to-top').addClass('show');
                } else {
                    jQuery('#back-to-top').removeClass('show');
                }
            };
        backToTop();
        jQuery(window).on('scroll', function() {
            backToTop();
        });
        jQuery('#back-to-top').on('click', function(e) {
            e.preventDefault();
            jQuery('html,body').animate({
                scrollTop: 0
            }, 600);
        });
    }
});
//
//

