
jQuery(document).ready(function($) {
                $(".fancybox").fancybox({
                  loop     : true
                });
            });
            new WOW().init();
