<?php get_header(); $get_i=''; ?>

	<main role="main">
	<!-- section -->
    <section id="page-post-detail" class="content">
            
	

	<?php if (have_posts()): while (have_posts()) : the_post(); ?>

		<!-- article -->
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="jumbotron jumbotron-fluid">
              <div class="container">
                <h1 class="h1-title-page"><span><?php the_title(); ?></span></h1>
              </div>
            </div> 
            
            <div class="container">
              <div class="detail-post">
                
                <div class="">                
                <?php //do_shortcode('[ez-toc]');
                 the_content();$get_i=get_the_ID(); // Dynamic Content ?>
                
                </div>
              </div>
            </div>
                 
			

		</article>
		<!-- /article -->

	<?php endwhile; ?>

	<?php else: ?>

		<!-- article -->
		<article>

			<h1><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h1>

		</article>
		<!-- /article -->

	<?php endif; ?>
          <div class="container">
              <div class="post_related m-t-30">
                <h2 class="block_hd"><span>Tin liên quan</span></h2>
                <ul  class="box-flex">
                <?php $args = array(
	'posts_per_page'   => 4,
	'offset'           => 0,
	'category'         => '',
	'category_name'    => '',
	'orderby'          => 'date',
	'order'            => 'DESC',
	'include'          => '',
	'exclude'          => $get_i,
	'meta_key'         => '',
	'meta_value'       => '',
	'post_type'        => get_post_type(),
	'post_mime_type'   => '',
	'post_parent'      => '',
	'author'	   => '',
	'author_name'	   => '',
	'post_status'      => 'publish',
	'suppress_filters' => true,
	'fields'           => '',
);
$posts_array = get_posts( $args ); 

foreach ( $posts_array as $post ) : setup_postdata( $post ); 

$featured_img_url = esc_url(get_the_post_thumbnail_url($post->ID,'medium'));
    $alt = get_post_meta( get_the_ID(), '_wp_attachment_image_alt', true);
                $tit = get_the_title(get_the_ID());
                $alt = empty($alt)?$tit:$alt;
    $featured_img_url = !empty($featured_img_url)?'<img src="'.$featured_img_url.'"   alt="'.$alt.'" title="'.$tit.'">':'';
?>
	
    <li>
                    <div class="box-img">
                      <a href="<?php echo get_permalink($post->ID);?>"><?php echo $featured_img_url;?></a>
                    </div>
                    <div class="box-caption-list">
                      <h2>
                        <a class="f2-text1" href="<?php echo get_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a>
                      </h2>
                      <div class="date"><?php echo get_the_time('F j, Y'); ?></div>
                    </div>
                  </li>
<?php endforeach; 
wp_reset_postdata();?>

                  
                 
                </ul>
              </div>
            </div>
	</section>
	<!-- /section -->
	</main>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>
