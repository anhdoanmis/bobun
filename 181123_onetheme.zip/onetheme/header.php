<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
	<head>
		<meta charset="<?php bloginfo('charset'); ?>">
		<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :'; } ?> <?php bloginfo('name'); ?></title>
        <?php 
            $redux_options = get_option('redux_demo');
            /*echo '<pre>';
            print_r($redux_options);
            echo '</pre>';*/
        ?>
		<link href="//www.google-analytics.com" rel="dns-prefetch">
        <link href="<?php echo $redux_options['favicon-media']['url'];?>?v=2" rel="shortcut icon">
        <link href="<?php echo $redux_options['favicon-media']['url'];?>?v=2" rel="apple-touch-icon-precomposed">

		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="<?php bloginfo('description'); ?>">

		<?php wp_head(); ?>
        
		<?php if(!empty($redux_options['header-script-textarea']))echo $redux_options['header-script-textarea'];?>
        

	</head>
	<body <?php body_class(); ?>>

		<div id="page">
         <!-- Main Header Start -->
          <header id="mobi">
            <div class="logo-mobi">
             <?php $alt = get_post_meta( $redux_options['logo-media']['id'], '_wp_attachment_image_alt', true);
                $tit = get_the_title($redux_options['logo-media']['id']);
                $alt = empty($alt)?$tit:$alt;?>
              <a href="<?php echo home_url();?>"><img src="<?php echo $redux_options['logo-media']['url'];?>" alt="<?php echo $alt;?>" title="<?php echo $tit;?>"></a>
            </div>
            
            <span class="btnShowgNavi ">
              <a href="#menu-mobi">
                <span></span>
                <span></span>
                <span></span>
              </a>
            </span>
            <nav id="menu-mobi">
              <div id="panel-menu">
              <?php wp_nav_menu(array('theme_location' =>'header-menu','menu_id'=>'menu-menu-chinh','menu_class'=>'menu')); ?>
                
              </div>
            </nav>
          </header>
           
          <header id="header">
            <div class="container">
              <div class="box-flex">
                <div class="logo-top">
                  <a href="<?php echo home_url();?>"><img src="<?php echo $redux_options['logo-media']['url'];?>" alt="<?php echo $alt;?>" title="<?php echo $tit;?>"></a>
                  
                </div>
                 
                <div class="menu-top-primary">
                
                  <nav class="primary-menu">
                     
                        <?php wp_nav_menu(array('theme_location' =>'header-menu','menu_id'=>'menu-menu-chinh','menu_class'=>'menu')); ?>
                        
                  </nav>
                </div>
              </div>
            </div>
          </header>   
