<?php get_header(); ?>

	
    <main role="main">
		<!-- section -->
        
                <div class="jumbotron jumbotron-fluid">
              <div class="container">
                <h1 class="h1-title-page"><span>Phong Thủy</span></h1>
              </div>
            </div>
		<section>
           <div class="container">
		
                 <div class="description-page m-t-30">
                   <?php
                        $redux_options = get_option('redux_demo');
                        echo wpautop($redux_options['phong-thuy-editor-tiny']);
                   ?>
              </div>
		    
            	<?php echo do_shortcode("[code_post_list post_type='phong-thuy']"); ?>
				

		</div>		

		</section>
		<!-- /section -->
	</main>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>
