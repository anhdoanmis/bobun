<?php get_header(); $get_i=''; ?>

	<main role="main">
	<!-- section -->
    <section id="page-post-detail" class="content">
            
	

	<?php if (have_posts()): while (have_posts()) : the_post(); ?>

		<!-- article -->
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="jumbotron jumbotron-fluid">
              <div class="container">
                <h1 class="h1-title-page"><span><?php the_title(); ?></span></h1>
              </div>
            </div> 
            
            <div class="container">
              <div class="detail-project">
                
                <div class=""> 
                               
                <?php 
                //do_shortcode('[ez-toc]');
                the_content();$get_i=get_the_ID(); // Dynamic Content ?>
                
                </div>
                <h2 class="center" id="vi_tri_noi_bat"><?php echo get_post_meta($get_i,'tieu_de_vi_tri_noi_bat',true);?></h2>
                <p class="center m-t-30">
                <?php
                    $hinh_l = get_post_meta($get_i,'hinh_vi_tri_noi_bat',true);
                    //echo esc_url(wp_get_attachment_url($hinh_l,'full'));
                    $alt = get_post_meta( $hinh_l, '_wp_attachment_image_alt', true);
                $tit = get_the_title($hinh_l);
                $alt = empty($alt)?$tit:$alt;
                if(!empty($hinh_l)):
                ?>
                <img  src="<?php echo esc_url(wp_get_attachment_url($hinh_l));?>" alt="<?php echo $alt; ?>" title="<?php echo $tit; ?>"></p>
                
                <?php
                 endif;
                 echo wpautop(get_post_meta($get_i,'noi_dung_vi_tri_noi_bat',true));?>
                    
			    <div class="pic-detail m-t-30">
                  <h2 class="center" id="mat_bang_tong_quan"><?php echo get_post_meta($get_i,'tieu_de_mat_bang_tong_quan',true);?></h2>
                  <div class="row m-t-30">
                  <?php
                      $hinh_l = get_post_meta($get_i,'hinh_mat_bang_tong_quan',true);
                    $h_l = explode(',',$hinh_l);
                    foreach($h_l as $h):                      
                     if(!empty($h)):
                    $alt = get_post_meta( $h, '_wp_attachment_image_alt', true);
                $tit = get_the_title($h);
                $alt = empty($alt)?$tit:$alt;
                      ?>
                    <div class="col-lg-4 col-sm-6">
                      <figure class="">
                      
                        <a href="<?php echo wp_get_attachment_url($h);?>" class="fancybox">
                          <img class="img-responsive" src="<?php echo wp_get_attachment_url($h);?>" alt="<?php echo $alt; ?>" title="<?php echo $tit; ?>">
                          <span class="zoom-icon gallery-icon"></span>
                        </a>
                      </figure>
                    </div>
                    <?php endif; endforeach;?>                   
                    
                  </div>
                </div>
                <div class="pic-detail m-t-30">
                  <h2 class="center" id="view_huong"><?php echo get_post_meta($get_i,'tieu_de_view_huong',true);?></h2>
                  <div class="row m-t-30">
                  <?php
                      $hinh_l = get_post_meta($get_i,'hinh_view_huong',true);
                    $h_l = explode(',',$hinh_l);
                    foreach($h_l as $h):                      
                     if(!empty($h)):
                    $alt = get_post_meta( $h, '_wp_attachment_image_alt', true);
                $tit = get_the_title($h);
                $alt = empty($alt)?$tit:$alt;
                      ?>
                    <div class="col-lg-4 col-sm-6">
                      <figure class="">
                      
                        <a href="<?php echo wp_get_attachment_url($h);?>" class="fancybox">
                          <img class="img-responsive" src="<?php echo wp_get_attachment_url($h);?>" alt="<?php echo $alt; ?>" title="<?php echo $tit; ?>">
                          <span class="zoom-icon gallery-icon"></span>
                        </a>
                      </figure>
                    </div>
                    <?php endif;endforeach;?>                   
                    
                  </div>
                </div>
                <div class="pic-detail m-t-30">
                  <h2 class="center" id="noi_that"><?php echo get_post_meta($get_i,'tieu_de_noi_that',true);?></h2>
                  <div class="row m-t-30">
                  <?php
                      $hinh_l = get_post_meta($get_i,'hinh_noi_that',true);
                    $h_l = explode(',',$hinh_l);
                    foreach($h_l as $h):                      
                          if(!empty($h)):
                    $alt = get_post_meta( $h, '_wp_attachment_image_alt', true);
                $tit = get_the_title($h);
                $alt = empty($alt)?$tit:$alt;
                      ?>
                    <div class="col-lg-4 col-sm-6">
                      <figure class="">
                      
                        <a href="<?php echo wp_get_attachment_url($h);?>" class="fancybox">
                          <img class="img-responsive" src="<?php echo wp_get_attachment_url($h);?>" alt="<?php echo $alt; ?>" title="<?php echo $tit; ?>">
                          <span class="zoom-icon gallery-icon"></span>
                        </a>
                      </figure>
                    </div>
                    <?php endif;endforeach;?>                   
                    
                  </div>
                </div>
                <div class="tien-ich">
                  <h2 class="center m-t-30 m-b-30" id="tien_ich"><?php echo get_post_meta($get_i,'tieu_de_tien_ich',true);?></h2>
                  <?php echo wpautop(get_post_meta($get_i,'noi_dung_tien_ich',true));?>
                </div>
                <div class="chu-dau-tu">
                  <h2 class="center" id="chu_dau_tu"><?php echo get_post_meta($get_i,'tieu_de_chu_dau_tu',true);?></h2>
                  <div class="wpb_wrapper">
                    <?php echo wpautop(get_post_meta($get_i,'noi_dung_chu_dau_tu',true));?>
                  </div>
                </div>
                
              </div>
            </div>
		</article>
		<!-- /article -->

	<?php endwhile; ?>

	<?php else: ?>

		<!-- article -->
		<article>

			<h1><?php _e( 'Xin lỗi, bài viết không được hiển thị.', 'html5blank' ); ?></h1>

		</article>
		<!-- /article -->

	<?php endif; ?>
          <div class="container">
              <div class="post_related m-t-30">
                <h2 class="block_hd"><span>Tin liên quan</span></h2>
                <ul  class="box-flex">
                <?php $args = array(
	'posts_per_page'   => 4,
	'offset'           => 0,
	'category'         => '',
	'category_name'    => '',
	'orderby'          => 'date',
	'order'            => 'DESC',
	'include'          => '',
	'exclude'          => $get_i,
	'meta_key'         => '',
	'meta_value'       => '',
	'post_type'        => 'post',
	'post_mime_type'   => '',
	'post_parent'      => '',
	'author'	   => '',
	'author_name'	   => '',
	'post_status'      => 'publish',
	'suppress_filters' => true,
	'fields'           => '',
);
$posts_array = get_posts( $args ); 

foreach ( $posts_array as $post ) : setup_postdata( $post ); 

$featured_img_url = esc_url(get_the_post_thumbnail_url($post->ID,'medium'));
    $alt = get_post_meta( get_the_ID(), '_wp_attachment_image_alt', true);
                $tit = get_the_title(get_the_ID());
                $alt = empty($alt)?$tit:$alt;
    $featured_img_url = !empty($featured_img_url)?'<img src="'.$featured_img_url.'"   alt="'.$alt.'" title="'.$tit.'">':'';
?>
	
    <li>
                   <div class="box-img">
                      <a href="<?php echo get_permalink($post->ID);?>"><?php echo $featured_img_url;?></a>
                    </div>
                    <div class="box-caption-list">
                      <h2>
                        <a class="f2-text1" href="<?php echo get_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a>
                      </h2>
                      <div class="date"><?php echo get_the_time('F j, Y'); ?></div>
                    </div>
                  </li>
<?php endforeach; 
wp_reset_postdata();?>

                  
                 
                </ul>
              </div>
            </div>
	</section>
     <section class="lien-he">
            <div class="container">
              <h2 class="title-block">Liên Hệ</h2>
              <div class="row">
                <div class="col-lg-6">
                  <div class="height" style="">
                    <?php echo do_shortcode('[contact-form-7 id="139" title="Form Liên Hệ"]');?>
                  </div>
                </div>
                <div class="col-lg-6">
                  <?php
                  $redux_options = get_option('redux_demo');
        echo 
        '<div class="address-contact">
                    <p><i class="'.$redux_options['icon-1-select-elusive'].'"></i>'.$redux_options['text-1-text'].'</p>
                    <p><i class="'.$redux_options['icon-2-select-elusive'].'"></i>'.$redux_options['text-2-text'].'</p>
                    <p><i class="'.$redux_options['icon-3-select-elusive'].'"></i>'.$redux_options['text-3-text'].'</p>
                    <p><i class="'.$redux_options['icon-4-select-elusive'].'"></i>'.$redux_options['text-4-text'].'</p>
                    
                    <div class="map">
                      '.htmlspecialchars_decode($redux_options['html-map-textarea']).'
                    </div>
                  </div>';
                  ?>
                </div>
              </div>
            </div>
          </section>
    
	<!-- /section -->
	</main>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>
