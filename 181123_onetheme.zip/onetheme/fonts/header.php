<?php
$favicon = get_field('favicon', 'option');
$logo = get_field('logo', 'option');
if ($logo){
    $logoUrl = $logo['url'];
}else{
    $logoUrl = get_stylesheet_directory_uri() . '/images/logo.png';
}
$size = 'full'; // (thumbnail, medium, large, full or custom size)
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if($favicon): ?>
    <link rel="icon" href="<?php echo $favicon['url']; ?>" />
    <link rel="shortcut icon" href="<?php echo $favicon['url']; ?>" />
    <?php else: ?>
    <link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon.ico" />
    <?php endif; ?>
    <!-- Favicon -->

    <!-- Title -->

    <!-- css file -->
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/bootstrap.min.css">

    <!-- scrolling-nav stylesheet -->
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/css/scrolling-nav.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/responsive.css">
    <!-- Responsive stylesheet -->
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/css/jquery.mmenu.all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/slick.css">
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/slick-theme.css">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php wp_head(); ?>

    <?php the_field('header_scripts', 'option'); ?>
</head>
<body <?php body_class(); ?>>
<div id="page">
    <!-- Main Header Start -->
    <header id="mobi">
            <span class="btnShowgNavi ">
              <a href="#menu-mobi">
                <span></span>
                <span></span>
                <span></span>
              </a>
            </span>
        <nav id="menu-mobi">
            <div id="panel-menu">
                <?php wp_nav_menu( array(
                    'container' => '',
                    'theme_location' => 'main',
                    'menu_id'        => '',
                    'menu_class' => 'sp-menu',
                    'position' => 'sp'
                ) ); ?>
            </div>
        </nav>
    </header>
    <header id="header">
        <div class="box-menu-primary">
            <div class="header-top">
                <div class="container-fix right">
                    <div class="search_top">
                        <?php get_search_form() ?>
                    </div>
                    <div class="language">
                        <?php $languages = icl_get_languages('skip_missing=N'); ?>
                        <span><a href="<?php echo $languages['vi']['url']; ?>">Vi</a></span>
                        <span>|</span>
                        <span><a href="<?php echo $languages['en']['url']; ?>">En</a></span>
                    </div>
                </div>
            </div>
            <div class="header-bottom">
                <div class="container-fix">
                    <div class="box-flex">
                        <div class="heade-min">
                            <a href="<?php echo home_url(); ?>" class="careplus-logo"><img src="<?php echo $logoUrl; ?>" alt="<?php bloginfo( 'name' ); ?>" title="<?php bloginfo( 'name' ); ?>"></a>
                        </div>
                        <div class="menu-home-primary">
                            <nav class="primary-menu">
                                <?php wp_nav_menu( array(
                                    'container' => '',
                                    'theme_location' => 'main',
                                    'menu_id'        => 'menu-menu-chinh',
                                    'menu_class' => 'menu',
                                    'position' => 'top'
                                ) ); ?>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>



